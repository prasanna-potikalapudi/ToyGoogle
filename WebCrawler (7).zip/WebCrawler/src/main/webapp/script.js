
//var list="${mylist}";
//document.getElementById("demo").innerHTML=list;


		function myFunction(x) {
		  x.classList.toggle("change");
		}
	